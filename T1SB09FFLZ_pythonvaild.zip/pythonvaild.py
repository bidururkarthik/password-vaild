password = input()
contain = False

for i in password:
    is_digit = i.isdigit()
    if is_digit:
        contain = True
        
upper_case = password.upper() == password
lower_case = password.lower() == password
contain_lower_and_upper = (not lower_case) and (not upper_case) 
is_vaild_password = (contain and contain_lower_and_upper)
    
if (is_vaild_password):
    print("Valid Password")
    
else:
    print("Invalid Password")